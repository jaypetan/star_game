import PoolManager from "./PoolManager";
import ProgressBar from "../UI/ProgressBar";
import SpawnLogic from "./SpawnLogic";
const { ccclass, property } = cc._decorator;

@ccclass
export default class Game extends cc.Component {
    // Game Configuration & Parameter
    @property
    private progressiveLightningLevels: number = 5;
    @property
    private baseLightningInterval: number = 6;
    @property
    private minLightningInterval: number = 2;
    public currentLightningInterval: number = 0;

    @property(cc.Node)
    public ground: cc.Node = undefined!;

    @property(cc.Node)
    public player: cc.Node = undefined!;

    @property(cc.Node)
    private deathScreenPanel: cc.Node = undefined!;

    @property(cc.Node)
    private gameplayButtonsContainer: cc.Node = undefined!;

    @property(cc.Node)
    private timerProgressBar: cc.Node = undefined!;

    @property(cc.Node)
    private spineBoyExpressionNode: cc.Node = undefined!;

    // UI & Audio References
    @property(cc.Label)
    private scoreDisplay: cc.Label = undefined!;

    @property(cc.Label)
    private highScoreDisplay: cc.Label = undefined!;

    @property(cc.Label)
    private messageLabel: cc.Label = undefined!;

    @property(cc.Sprite)
    private pauseButtonSprite: cc.Sprite = undefined!;

    @property(cc.SpriteFrame)
    private pauseIconSpriteFrame: cc.SpriteFrame = undefined!;

    @property(cc.SpriteFrame)
    private playIconSpriteFrame: cc.SpriteFrame = undefined!;

    @property(cc.AudioClip)
    private scoreAudio: cc.AudioClip = undefined!;

    // Runtime State Variables
    @property(cc.Integer)
    private score: number = 0;

    private isPaused: boolean = false;
    public isGameOver: boolean = false;

    public rightBorder: number = 0;
    public leftBorder: number = 0;
    public groundY: number = 0;
    private timer: number = 0;
    private starDuration: number = 0;

    private poolManager: PoolManager = null!;
    private spawnLogic: SpawnLogic = null!;

    protected onLoad() {
        this.initGame();
    }

    protected start() {
        // Initialize star and lightning
        this.spawnLogic.spawnStar();
        this.currentLightningInterval = this.baseLightningInterval;
        this.spawnLogic.rescheduleLightning();
    }

    private initGame() {
        // Init other scripts
        this.poolManager = this.getComponent("PoolManager");
        this.poolManager.initializeNodePools();
        this.spawnLogic = this.getComponent("SpawnLogic");

        // Boundary set up
        this.calculateBoundaries();
        this.player
            .getComponent("Player")
            .setUpBoundaries(this.groundY, this.leftBorder, this.rightBorder);

        // Flag state setup
        this.isGameOver = false;
        this.isPaused = false;

        // Keyboard listener for pause button
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);

        // Reset timer and display
        this.scoreDisplay.string = "Score: " + this.score.toString();
        this.timer = 0;
        this.starDuration = 0;

        // Load and display the current high score
        let savedHighScore = cc.sys.localStorage.getItem("starCollector_highscore") || 0;
        this.highScoreDisplay.string = "Best: " + savedHighScore;
    }

    protected update(dt: number) {
        if (this.isPaused) return;
        if (this.starDuration <= 0) return;

        this.timer += dt;

        // Update ProgressBar
        this.timerProgressBar
            .getComponent(ProgressBar)
            .setProgressBar(this.timer, this.starDuration);

        // Trigger game over if the player runs out of time
        if (this.timer > this.starDuration && !this.isGameOver) {
            this.gameOver();
        }
    }

    protected onKeyDown(event: any) {
        // Pause on pressed "P" key
        if (event.keyCode === cc.macro.KEY.p) {
            this.togglePauseGame();
        }
    }

    // Other game functions
    public gameOver() {
        if (this.isGameOver) return;
        this.isGameOver = true;
        this.unschedule(this.spawnLogic.spawnLightning);

        // Trigger the player's death animation
        let playerScript = this.player.getComponent("Player") as any;
        playerScript.playDeathAnimation(this.groundY, () => {
            this.player.active = false;
            if (this.deathScreenPanel) {
                this.deathScreenPanel.active = true;
            }
        });

        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);

        // Hide UI buttons
        this.gameplayButtonsContainer.active = false;
        this.saveHighscore();
    }

    private calculateBoundaries() {
        // Boundary set up
        this.groundY = this.ground.y + this.ground.height / 2;
        let canvasWidth = this.node ? this.node.width : 960;
        let maxX = canvasWidth / 2;

        // Factor in player size to prevent sprite edge clipping
        let halfPlayerWidth = this.player.width / 2;
        this.rightBorder = maxX - halfPlayerWidth;
        this.leftBorder = -this.rightBorder;
    }

    private saveHighscore() {
        let rawSavedScore = cc.sys.localStorage.getItem("starCollector_highscore");
        let savedHighScore = rawSavedScore ? parseInt(rawSavedScore) : 0;

        // Check if the player just beat their old record
        if (this.score > savedHighScore) {
            savedHighScore = this.score;
            cc.sys.localStorage.setItem("starCollector_highscore", savedHighScore.toString());
        }

        // Display the high score on the final screen text interface
        if (this.highScoreDisplay) {
            this.highScoreDisplay.string = "Best: " + savedHighScore.toString();
        }
    }

    // UI Button Functions
    public restartGame() {
        cc.director.loadScene("starchaser");
    }

    public togglePauseGame() {
        this.isPaused = !this.isPaused;
        cc.director.getScheduler().setTimeScale(this.isPaused ? 0 : 1);

        // Toggle sprite frame
        if (this.pauseButtonSprite) {
            this.pauseButtonSprite.spriteFrame = this.isPaused
                ? this.playIconSpriteFrame
                : this.pauseIconSpriteFrame;
        }
    }

    public goToMainMenu() {
        cc.director.loadScene("mainMenu");
    }

    public setStarAndTimer(starDuration: number, timer: number) {
        this.starDuration = starDuration;
        this.timer = timer;
    }

    public gainScore() {
        // Increment score value
        this.score += 1;

        // Update the visual UI string
        this.scoreDisplay.string = "Score: " + this.score.toString();

        // Play the pickup audio snippet
        cc.audioEngine.playEffect(this.scoreAudio, false);

        // Increase lightning difficulty over time
        this.increaseLightningDifficulty();

        // Check level and set it accordingly
        this.checkAndSetProgressiveLevel();
    }

    private increaseLightningDifficulty() {
        if (
            this.score > 0 &&
            this.score % this.progressiveLightningLevels === 0 &&
            this.currentLightningInterval > this.minLightningInterval &&
            !this.spawnLogic.isThunderstorm
        ) {
            this.currentLightningInterval = Math.max(
                this.currentLightningInterval - 0.5 * Math.random(),
                this.minLightningInterval
            );
            this.spawnLogic.unschedule(this.spawnLogic.spawnLightning);
            this.spawnLogic.rescheduleLightning();
        }
    }

    private checkAndSetProgressiveLevel() {
        switch (this.score) {
            case 20:
                this.setVisualWithSpineBoy("STOP STEALING MY STARS!", "walk");
                this.scheduleOnce(() => {
                    this.spawnLogic.toggleCharger(true, 400);
                }, 3.0);
                break;

            case 40:
                this.setVisualWithSpineBoy("TAKE THIS!", "shoot");
                this.scheduleOnce(() => {
                    this.spawnLogic.togglePortal(true);
                }, 1.0);
                break;

            case 60:
                this.setVisualWarning("ARRRGHHH");
                this.setLargerVisualWarning();
                this.scheduleOnce(() => {
                    this.spawnLogic.toggleThunderstorm(true);
                }, 1.0);
                break;

            case 80:
                this.setVisualWithSpineBoy("IM COMING FOR YOU!", "run");
                this.scheduleOnce(() => {
                    this.spawnLogic.toggleCharger(true, 1200);
                }, 3.0);
                break;

            case 100:
                this.setVisualWarning("FULL CHARGEEEEE");
                this.setLargerVisualWarning();
                this.spawnLogic.toggleForever();
                break;
        }
    }

    private setVisualWithSpineBoy(visualText: string, animation: string) {
        this.spineBoyExpressionNode.active = true;
        this.spineBoyExpressionNode.opacity = 0;
        cc.tween(this.spineBoyExpressionNode).to(0.5, { opacity: 255 }).start(); // Fade In

        let spineboy = this.spineBoyExpressionNode.getChildByName("spineboy");
        let skeleton = spineboy.getComponent(sp.Skeleton);

        // Set text and animation
        this.setVisualWarning(visualText);
        skeleton.setAnimation(0, animation, true);

        if (this.spineBoyExpressionNode.active) {
            cc.tween(this.spineBoyExpressionNode)
                .delay(3)
                .to(0.5, { opacity: 0 })
                .call(() => {
                    cc.Tween.stopAllByTarget(this.spineBoyExpressionNode);
                    this.spineBoyExpressionNode.active = false;
                })
                .start();
        }
    }

    // Adjustment to the visual text
    private setVisualWarning(message: string) {
        this.messageLabel.node.active = true;
        this.messageLabel.string = message;
        this.messageLabel.node.opacity = 0;

        cc.Tween.stopAllByTarget(this.messageLabel.node);
        cc.tween(this.messageLabel.node).to(0.5, { opacity: 255 }).start(); // Fade In

        cc.tween(this.messageLabel.node)
            .delay(3)
            .to(0.5, { opacity: 0 })
            .call(() => {
                this.messageLabel.string = "";
                this.messageLabel.node.active = false;
            })
            .start();
    }

    private setLargerVisualWarning() {
        this.messageLabel.node.y += 100;
        this.messageLabel.node.scale = 1.3;

        this.scheduleOnce(() => {
            this.messageLabel.node.y -= 100;
            this.messageLabel.node.scale = 1.0;
        }, 4.0);
    }
}
