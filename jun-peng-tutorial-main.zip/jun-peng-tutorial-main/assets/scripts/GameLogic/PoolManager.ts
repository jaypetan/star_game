const { ccclass, property } = cc._decorator;

@ccclass
export default class PoolManager extends cc.Component {
    @property(cc.Prefab)
    private starPrefab: cc.Prefab = undefined!;

    @property(cc.Prefab)
    private lightningPrefab: cc.Prefab = undefined!;

    @property(cc.Prefab)
    private portalPrefab: cc.Prefab = undefined!;

    @property(cc.Prefab)
    private chargerPrefab: cc.Prefab = undefined!;

    // Node Pools
    private starPool: cc.NodePool = null!;
    private lightningPool: cc.NodePool = null!;
    private portalPool: cc.NodePool = null!;
    private chargerPool: cc.NodePool = null!;

    public initializeNodePools() {
        this.lightningPool = new cc.NodePool();
        this.portalPool = new cc.NodePool();
        this.starPool = new cc.NodePool();
        this.chargerPool = new cc.NodePool();

        // Preloading Pools
        this.preloadPools();
    }

    private preloadPool(prefab: cc.Prefab, pool: cc.NodePool, count: number): void {
        if (!prefab) return;
        for (let i = 0; i < count; i++) {
            let node = cc.instantiate(prefab);
            pool.put(node);
        }
    }

    private preloadPools() {
        this.preloadPool(this.starPrefab, this.starPool, 5);
        this.preloadPool(this.lightningPrefab, this.lightningPool, 20);
        this.preloadPool(this.portalPrefab, this.portalPool, 4);
        this.preloadPool(this.chargerPrefab, this.chargerPool, 2);
    }

    // Getter and Setter Function
    private getObjectFromPool(pool: cc.NodePool, prefab: cc.Prefab): cc.Node {
        let node = pool.size() > 0 ? pool.get()! : cc.instantiate(prefab);
        return node;
    }
    private setObjectFromPool(node: cc.Node, spawnPos: cc.Vec2, parentNode: cc.Node): cc.Node {
        node.active = true;
        node.parent = parentNode;
        node.setPosition(spawnPos);

        return node;
    }

    // Functions to spawn each Node
    public getAndSetStar(spawnPos: cc.Vec2, parentNode: cc.Node) {
        let node = this.getObjectFromPool(this.starPool, this.starPrefab);
        node = this.setObjectFromPool(node, spawnPos, parentNode);
        return node;
    }
    public getAndSetLightning(spawnPos: cc.Vec2, parentNode: cc.Node) {
        let node = this.getObjectFromPool(this.lightningPool, this.lightningPrefab);
        node = this.setObjectFromPool(node, spawnPos, parentNode);
        return node;
    }
    public getAndSetPortal(spawnPos: cc.Vec2, parentNode: cc.Node) {
        let node = this.getObjectFromPool(this.portalPool, this.portalPrefab);
        node = this.setObjectFromPool(node, spawnPos, parentNode);
        return node;
    }
    public getAndSetCharger(spawnPos: cc.Vec2, parentNode: cc.Node) {
        let node = this.getObjectFromPool(this.chargerPool, this.chargerPrefab);
        node = this.setObjectFromPool(node, spawnPos, parentNode);
        return node;
    }

    // Recycle Function
    private recycleNode(node: cc.Node, nodePool: cc.NodePool): void {
        if (!node || !cc.isValid(node)) return;
        node.active = false;
        node.removeFromParent();
        nodePool.put(node);
    }

    // Functions to recycle nodes
    public recycleStar(node: cc.Node): void {
        this.recycleNode(node, this.starPool);
    }
    public recycleLightning(node: cc.Node): void {
        this.recycleNode(node, this.lightningPool);
    }
    public recyclePortal(node: cc.Node): void {
        this.recycleNode(node, this.portalPool);
    }
    public recycleCharger(node: cc.Node): void {
        this.recycleNode(node, this.chargerPool);
    }
}
