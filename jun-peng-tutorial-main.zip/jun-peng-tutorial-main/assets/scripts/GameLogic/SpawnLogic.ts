import Game from "./Game";
import PoolManager from "./PoolManager";

const { ccclass, property } = cc._decorator;

@ccclass
export default class SpawnLogic extends cc.Component {
    private poolManager: PoolManager = undefined!;
    private gameManager: Game = undefined!;

    @property
    private minStarDuration: number = 5;
    @property
    private maxStarDuration: number = 7;

    @property
    private chargerDuration: number = 10;
    @property
    private thunderStormFrequency: number = 0.5;
    @property
    private thunderStormDuration: number = 10;
    @property
    private portalFrequency: number = 2;
    @property
    private portalDuration: number = 10;

    @property(cc.Node)
    public player: cc.Node = undefined!;
    @property(cc.Node)
    private spawnerContainer: cc.Node = undefined!;

    public isChargerActivated: boolean = false;
    public isThunderstorm: boolean = false;
    public isPortalPhaseActive: boolean = false;

    protected onLoad(): void {
        this.poolManager = this.getComponent("PoolManager");
        this.gameManager = this.getComponent("Game");
    }

    // Star mechanics
    public spawnStar(): void {
        let newStar = this.poolManager.getAndSetStar(
            this.getNewStarPosition(),
            this.spawnerContainer
        );

        // Pass a reference of this game script to the star's script component
        let starScript = newStar.getComponent("Star") as any;
        if (starScript) {
            starScript.game = this;
            starScript.initStar();

            // Pass down relevant functions
            starScript.setGainScore(() => this.gameManager.gainScore());
            starScript.setSpawnStar(() => this.spawnStar());
            starScript.setRecycleStar((node: cc.Node) => this.poolManager.recycleStar(node));
        }

        // Generate a random lifetime limit for this specific star
        let starDuration =
            this.minStarDuration + Math.random() * (this.maxStarDuration - this.minStarDuration);

        this.gameManager.setStarAndTimer(starDuration, 0); //set star duration and timer
    }

    private getNewStarPosition(): cc.Vec2 {
        let starHeight = 35;
        let starWidth = 60;

        // Random Y
        let jumpHeight = this.player.getComponent("Player").getJumpHeight();
        let randY = this.gameManager.groundY + Math.random() * jumpHeight + starHeight;

        // Random X
        let maxX = (this.gameManager.rightBorder - this.gameManager.leftBorder) / 2 - starWidth / 2;
        let randX = (Math.random() - 0.5) * 2 * maxX;

        return cc.v2(randX, randY);
    }

    // // In-game mechanics
    // // Charger
    public toggleCharger(active: boolean, speed?: number): void {
        if (active === this.isChargerActivated) return;
        this.isChargerActivated = active;

        if (active) {
            let spawnSide = Math.random() < 0.5 ? "left" : "right";
            this.setChargerLocationAndSpeed(spawnSide, speed);
        }
    }

    public setChargerLocationAndSpeed(location: string, speed?: number): void {
        if (this.gameManager.isGameOver) return;

        let spawnX = this.gameManager.rightBorder + 100;
        if (location === "left") spawnX *= -1;
        let spawnPos = cc.v2(spawnX, this.gameManager.groundY);

        let chargerNode = this.poolManager.getAndSetCharger(spawnPos, this.spawnerContainer);
        let chargerScript = chargerNode.getComponent("Charger");
        chargerScript.initCharger(this.player, spawnX, this.chargerDuration);

        if (!speed) return;
        chargerScript.moveSpeed = speed;
        chargerScript.setUpBoundaries(this.gameManager.leftBorder, this.gameManager.rightBorder);

        chargerScript.toggleCharger = (activated: boolean) => {
            this.toggleCharger(activated);
        };
        chargerScript.setRecycleCharger((node: cc.Node) => {
            this.poolManager.recycleCharger(node);
        });
    }

    // Lightning
    public spawnLightning(): void {
        if (this.gameManager.isGameOver) return;

        // Pick a completely randomized horizontal point across the screen field
        let minX = this.gameManager.leftBorder + 60;
        let maxX = this.gameManager.rightBorder - 60;
        let targetX = minX + Math.random() * (maxX - minX);

        // Strike spans vertically from top to bottom at the targeted X grid point
        let spawnPos = cc.v2(targetX, this.gameManager.groundY);
        let node = this.poolManager.getAndSetLightning(spawnPos, this.spawnerContainer);

        let lightningScript = node.getComponent("Lightning") as any;
        if (lightningScript) {
            lightningScript.player = this.player;
            lightningScript.setRecycleLightning((node: cc.Node) => {
                this.poolManager.recycleLightning(node);
            });
            lightningScript.initStrike();
        }
    }

    public rescheduleLightning() {
        this.schedule(this.spawnLightning, this.gameManager.currentLightningInterval);
    }

    // Thunderstorm
    public toggleThunderstorm(active: boolean): void {
        if (active === this.isThunderstorm) return;
        this.isThunderstorm = active;
        this.unschedule(this.spawnLightning);

        if (active) {
            this.schedule(this.spawnLightning, this.thunderStormFrequency);
            this.shakePlatform(this.thunderStormDuration + 1.0, 10);

            this.scheduleOnce(this.endThunderstorm, this.thunderStormDuration);
        } else {
            if (this.gameManager.isGameOver) return;
            this.rescheduleLightning();
        }
    }

    public shakePlatform(duration: number, intensity: number): void {
        let originalPos = this.gameManager.ground.getPosition();
        cc.Tween.stopAllByTarget(this.gameManager.ground);

        let shakeInterval = 0.05; // how often to pick a new random offset
        let steps = Math.floor(duration / shakeInterval);

        let tween = cc.tween(this.gameManager.ground);
        for (let i = 0; i < steps; i++) {
            tween = tween.to(shakeInterval, {
                x: originalPos.x + (Math.random() - 0.5) * 2 * intensity,
                y: originalPos.y + (Math.random() - 0.5) * 2 * intensity,
            });
        }
        tween
            .to(shakeInterval, { x: originalPos.x, y: originalPos.y }) // snap back to original
            .start();
    }

    private endThunderstorm(): void {
        this.toggleThunderstorm(false);
    }

    // Portals
    public togglePortal(active: boolean): void {
        if (active === this.isPortalPhaseActive) return;

        this.isPortalPhaseActive = active;

        if (active && !this.gameManager.isGameOver) {
            this.schedule(this.spawnPortalPair, this.portalFrequency);
            this.scheduleOnce(this.endPortal, this.portalDuration);
        }
    }

    private endPortal(): void {
        this.togglePortal(false);
        this.unschedule(this.spawnPortalPair);
    }

    private spawnPortalPair(): void {
        if (this.gameManager.isGameOver || this.isThunderstorm) return;

        // Determine y
        let halfPortalHeight = 70; // with buffer
        let jumpHeight = this.player.getComponent("Player").baseJumpHeight;
        let randomY1 = this.gameManager.groundY + Math.random() * jumpHeight + halfPortalHeight;
        let randomY2 = this.gameManager.groundY + Math.random() * jumpHeight + halfPortalHeight;

        // Determine x
        let minDistance = 150;

        let leftZoneMinX = this.gameManager.leftBorder + 100;
        let leftZoneMaxX = 0 - minDistance / 2;
        let firstX = leftZoneMinX + Math.random() * (leftZoneMaxX - leftZoneMinX); // Left half of screen

        let rightZoneMinX = 0 + minDistance / 2;
        let rightZoneMaxX = this.gameManager.rightBorder - 100;
        let secondX = rightZoneMinX + Math.random() * (rightZoneMaxX - rightZoneMinX); // Right half of screen

        // Apply the positions to nodes
        let firstNodePos = cc.v2(firstX, randomY1);
        let secondNodePos = cc.v2(secondX, randomY2);
        let firstNode = this.poolManager.getAndSetPortal(firstNodePos, this.spawnerContainer);
        let secondNode = this.poolManager.getAndSetPortal(secondNodePos, this.spawnerContainer);

        // Adjust the component
        firstNode.color = new cc.Color().fromHEX("#F84BFF");
        secondNode.color = cc.Color.WHITE;
        let firstPortal = firstNode.getComponent("Portal") as any;
        let secondPortal = secondNode.getComponent("Portal") as any;

        // Set identity and link dependencies for the first portal component
        if (firstPortal) {
            firstPortal.portalType = "first";
            firstPortal.linkedPortal = secondPortal;
            firstPortal.playerNode = this.player;
            firstPortal.setRecyclePortal((node: cc.Node) => {
                this.poolManager.recyclePortal(node);
            });
            firstPortal.initPortalLifecycle();
        }

        // Set identity and link dependencies for the second portal component
        if (secondPortal) {
            secondPortal.portalType = "second";
            secondPortal.linkedPortal = firstPortal;
            secondPortal.playerNode = this.player;
            secondPortal.setRecyclePortal((node: cc.Node) => {
                this.poolManager.recyclePortal(node);
            });
            secondPortal.initPortalLifecycle();
        }
    }

    public toggleForever() {
        this.schedule(
            () => {
                this.toggleCharger(true, 1600);
            },
            this.chargerDuration,
            cc.macro.REPEAT_FOREVER
        );
        this.schedule(
            () => {
                this.togglePortal(true);
            },
            this.portalDuration,
            cc.macro.REPEAT_FOREVER
        );
    }
}
