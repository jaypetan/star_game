const { ccclass, property } = cc._decorator;

@ccclass
export default class Portal extends cc.Component {
    @property
    private interactionRadius: number = 45;

    @property(cc.Node)
    private playerNode: cc.Node = undefined!;

    @property
    private warningDelay: number = 1.0;

    @property
    private portalDuration: number = 2.0;

    @property(cc.AudioClip)
    private teleportSound: cc.AudioClip = undefined!;

    public linkedPortal: Portal = undefined!;
    public isActivePortal: boolean = false;
    private portalAnim: cc.Animation = undefined!;

    private recyclePortal!: (node: cc.Node) => void;
    public setRecyclePortal(recyclePortal: () => void) {
        this.recyclePortal = recyclePortal;
    }

    protected onLoad(): void {
        this.initPortalLifecycle();
    }

    protected update(dt: number): void {
        if (!this.linkedPortal || !this.playerNode) return;

        // Calculate distance from slime center to portal center using vector subtraction
        let dist = this.node.getPosition().sub(this.playerNode.getPosition()).mag();

        // Trigger teleportation if the player enters the interaction radius
        if (dist < this.interactionRadius && this.isActivePortal) {
            this.teleportPlayer();
        }
    }

    private initPortalLifecycle(): void {
        this.node.scale = 0; // Initialize tiny
        this.node.opacity = 50; // Start semi-transparent (warning phase)
        this.isActivePortal = false; // Block teleportation early

        cc.Tween.stopAllByTarget(this.node);
        cc.tween(this.node)
            // Pop open into the "Warning Phase"
            .to(this.warningDelay, { scale: 1.0 }, { easing: "backOut" })

            // Bounce
            .to(0.15, { scale: 1.2, opacity: 150 }, { easing: "quadOut" })

            // Activate the portal
            .call(() => {
                this.isActivePortal = true; // Enable teleportation functionality
                this.activatePortal();

                let portalAnim = this.node.getComponent(cc.Animation);
                if (portalAnim) {
                    portalAnim.play("portal"); // Start spinning frame-by-frame
                }
            })

            .to(0.15, { scale: 1.0, opacity: 255 }, { easing: "quadIn" })

            .delay(this.portalDuration)

            // Shrink away smoothly
            .to(1.0, { scale: 0.0 }, { easing: "backIn" })
            .call(() => {
                // Self-destruct safely when the entire lifecycle finishes
                if (cc.isValid(this.node)) {
                    this.recyclePortal(this.node);
                }
            })
            .start();
    }

    private activatePortal(): void {
        this.node.opacity = 255; // Full solid visibility
        this.isActivePortal = true; // Player can now be teleported
        if (this.portalAnim) {
            this.portalAnim.play("portal");
        }
    }

    private teleportPlayer(): void {
        // Check
        let playerScript = this.playerNode.getComponent("Player") as any;
        if (!playerScript || playerScript.isTeleportCooldown) return;
        playerScript.isTeleportCooldown = true; // Prevent looping

        // Instantly move the player node to the linked sister portal position coordinates
        let targetPosition = this.linkedPortal.node.getPosition();
        this.playerNode.setPosition(targetPosition);

        // Play portal sound
        if (this.teleportSound) {
            cc.audioEngine.playEffect(this.teleportSound, false);
        }

        // Shrink and delete both portals
        cc.Tween.stopAllByTarget(this.node);
        cc.tween(this.node)
            .to(1.0, { scale: 0.0 }, { easing: "backIn" })
            .call(() => {
                if (cc.isValid(this.node)) {
                    this.recyclePortal(this.node);
                }
                playerScript.isTeleportCooldown = false;
            })
            .start();

        cc.Tween.stopAllByTarget(this.linkedPortal.node);
        cc.tween(this.linkedPortal.node)
            .to(1.0, { scale: 0.0 }, { easing: "backIn" })
            .call(() => {
                if (cc.isValid(this.linkedPortal.node)) {
                    this.recyclePortal(this.linkedPortal.node);
                }
            })
            .start();
    }
}
