const { ccclass, property } = cc._decorator;

@ccclass
export default class Lightning extends cc.Component {
    @property
    private warningDuration: number = 2.0;

    @property
    private boltWidth: number = 32;

    @property
    private stunChance: number = 0.8;

    @property
    private stunDuration: number = 2.0;

    @property
    private speedBoostDuration: number = 2.0;

    @property(cc.AudioClip)
    private strikeSound: cc.AudioClip = undefined!;

    @property(cc.Node)
    private boltSprite: cc.Node = undefined!;

    private player: cc.Node = undefined!;
    private warningLine: cc.Node = undefined!;
    private boltAnim: cc.Animation = undefined!;
    private effect: string = "OVERDRIVE";

    private recycleLightning!: (node: cc.Node) => void;
    public setRecycleLightning(recycleLightning: (node: cc.Node) => void) {
        this.recycleLightning = recycleLightning;
    }

    public initStrike(): void {
        this.boltSprite.active = false;
        this.effect = Math.random() < this.stunChance ? "STUN" : "OVERDRIVE";
        this.playWarningSequence();
    }

    protected onLoad(): void {
        this.warningLine = this.node.getChildByName("WarningLine");
        this.boltAnim = this.boltSprite.getComponent(cc.Animation);
        this.boltSprite.active = false;

        // Decide whether to stun / speed boost
        if (Math.random() < this.stunChance) {
            this.effect = "STUN";
        } else {
            this.effect = "OVERDRIVE";
        }

        // Start the sequence chain
        this.playWarningSequence();
    }

    // Sequence for lightning strike
    private playWarningSequence(): void {
        this.warningLine.active = true;
        this.warningLine.color = this.effect === "STUN" ? cc.Color.YELLOW : cc.Color.RED;

        // Make the warning line pulse rapidly
        cc.Tween.stopAllByTarget(this.warningLine);
        cc.tween(this.warningLine)
            .repeat(
                4,
                cc
                    .tween()
                    .to(this.warningDuration / 8, { opacity: 40 })
                    .to(this.warningDuration / 8, { opacity: 10 })
            )
            .call(() => {
                this.executeStrike();
            })
            .start();
    }

    private executeStrike(): void {
        // Switch from warning line to lightning bolt
        if (this.boltSprite) {
            this.warningLine.active = false;
            this.boltSprite.active = true;
            this.boltSprite.color = this.effect === "STUN" ? cc.Color.WHITE : cc.Color.RED;

            if (this.boltAnim) {
                this.boltAnim.play();
                this.boltAnim.once("finished", this.onStrikeFinished, this);
            }
        }

        if (this.strikeSound) {
            cc.audioEngine.playEffect(this.strikeSound, false);
        }

        // Collision calculation
        let distanceX = Math.abs(this.player.x - this.node.x);
        let playerWidthHalf = this.player.width / 2;

        // Chance for speed boost / stun
        if (distanceX < this.boltWidth / 2 + playerWidthHalf) {
            let playerScript = this.player.getComponent("Player") as any;
            if (playerScript && playerScript.enabled) {
                if (this.effect === "STUN") {
                    playerScript.applyLightningEffect("STUN", this.stunDuration);
                } else {
                    playerScript.applyLightningEffect("OVERDRIVE", this.speedBoostDuration);
                }
            }
        }
    }

    private onStrikeFinished(): void {
        if (this.boltSprite) {
            this.boltSprite.active = false;
        }

        if (cc.isValid(this.node) && this.node.active) {
            this.recycleLightning(this.node);
        }
    }
}
