const { ccclass, property } = cc._decorator;

@ccclass
export default class Star extends cc.Component {
    @property(cc.Prefab)
    private particlePrefab: cc.Prefab = undefined!;

    private pickRadius: number = 60;
    public game: any = undefined!;

    private gainScore!: () => void;
    public setGainScore(gainScore: () => void) {
        this.gainScore = gainScore;
    }

    private spawnStar!: () => void;
    public setSpawnStar(spawnStar: () => void) {
        this.spawnStar = spawnStar;
    }

    private recycleStar!: (node: cc.Node) => void;
    public setRecycleStar(recycleStar: (node: cc.Node) => void) {
        this.recycleStar = recycleStar;
    }

    public initStar(): void {
        this.pickRadius = 60;
        this.node.opacity = 255;
        this.node.scale = 1;
    }

    protected update(dt: number): void {
        if (!this.game || !this.game.player) return;

        // Check if the player is close enough to collect the star
        if (this.getPlayerDistance() < this.pickRadius) {
            this.onPicked();
            return;
        }

        // Dynamically fade the star opacity
        let opacityRatio = 1 - this.game.timer / this.game.starDuration;
        let minOpacity = 50;
        this.node.opacity = minOpacity + Math.floor(opacityRatio * (255 - minOpacity));
    }

    private getPlayerDistance(): number {
        // Fetch the player character's current position vector
        let playerPos = this.game.player.getPosition();

        // Calculate the absolute distance between this star and the player
        let dist = this.node.position.sub(playerPos).mag();
        return dist;
    }

    private onPicked(): void {
        // Spawn the sparkle particle burst effect if the prefab is assigned
        if (this.particlePrefab) {
            let burst = cc.instantiate(this.particlePrefab);
            this.node.parent.addChild(burst);
            burst.setPosition(this.node.getPosition());

            // Auto-destroy the particle system node after 1 second so memory stays clean
            cc.tween(burst)
                .delay(1.0)
                .call(() => {
                    burst.destroy();
                })
                .start();
        }

        // Tell the game manager to spawn a replacement star
        if (this.game) {
            this.spawnStar();
            this.gainScore();
        }

        // Turn off collision tracking immediately so the star cannot be double-collected during the animation
        this.pickRadius = 0;

        // Play a smooth shrink animation before destroying the node completely
        cc.tween(this.node)
            .to(0.15, { scale: 0.0 }, { easing: "backIn" })
            .call(() => {
                if (cc.isValid(this.node)) {
                    this.recycleStar(this.node);
                }
            })
            .start();
    }
}
