const { ccclass, property } = cc._decorator;

@ccclass
export default class Charger extends cc.Component {
    private moveSpeed: number = 300;

    @property
    private hitRadius: number = 50;

    @property
    private knockbackX: number = 1000;

    @property
    private knockbackY: number = 300;

    public game: any = undefined!;
    public playerNode: cc.Node = undefined!;

    private hasHitPlayer: boolean = false;
    private direction: number = 1; // 1 = moving right, -1 = moving left
    private chargerDuration = 10;

    private leftBorder: number = 0;
    private rightBorder: number = 0;
    public setUpBoundaries(leftBorder: number, rightBorder: number) {
        this.leftBorder = leftBorder;
        this.rightBorder = rightBorder;
    }

    private toggleCharger!: (activated: boolean) => void;
    public setToggleCharger(toggleCharger: (activated: boolean) => void) {
        this.toggleCharger = toggleCharger;
    }

    private recycleCharger!: (node: cc.Node) => void;
    public setRecycleCharger(recycleCharger: () => void) {
        this.recycleCharger = recycleCharger;
    }

    public initCharger(playerNode: cc.Node, spawnX: number, chargerDuration: number) {
        this.playerNode = playerNode;
        this.hasHitPlayer = false;
        this.chargerDuration = chargerDuration;

        // Face and move toward whichever side the player is on
        this.direction = playerNode.x >= spawnX ? 1 : -1;
        this.node.scaleX = Math.abs(this.node.scaleX) * this.direction;
    }

    protected update(dt: number) {
        // Move toward the player
        this.node.x += this.moveSpeed * this.direction * dt;
        this.chargerDuration -= dt;

        // Check collision to hit the player once
        this.checkCollision();
        this.checkBoundaries();
    }

    private checkCollision() {
        // Check collision to hit the player once
        if (!this.hasHitPlayer && this.playerNode) {
            let playerPos = this.playerNode.getPosition();
            let targetNode = this.node.getPosition();
            let targetPosition = cc.v2(targetNode.x, targetNode.y + this.node.height / 8);

            let dist = targetPosition.sub(playerPos).mag();
            if (dist < this.hitRadius) {
                this.hitPlayer();
            }
        }
    }

    private hitPlayer() {
        this.hasHitPlayer = true;

        let playerScript = this.playerNode.getComponent("Player") as any;
        if (playerScript) {
            playerScript.applyKnockback(this.direction * this.knockbackX, this.knockbackY);
        }
    }

    private checkBoundaries() {
        let leftBoundary = this.leftBorder - this.node.width - 10;
        let rightBoundary = this.rightBorder + this.node.width + 10;

        // Reset the charger once past the boundaries
        if (this.node.x < leftBoundary || this.node.x > rightBoundary) {
            if (this.chargerDuration > 0) {
                this.initCharger(this.playerNode, this.node.x, this.chargerDuration);
            } else {
                this.toggleCharger(false);
                this.recycleCharger(this.node);
            }
        }
    }
}
