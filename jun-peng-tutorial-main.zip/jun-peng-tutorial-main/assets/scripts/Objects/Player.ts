const { ccclass, property } = cc._decorator;

@ccclass
export default class Player extends cc.Component {
    @property
    private baseJumpHeight: number = 400;

    @property
    private jumpSpeed: number = 400;

    @property
    private maxMoveSpeed: number = 400;

    @property
    private accel: number = 1000;

    @property(cc.AudioClip)
    private jumpAudio: cc.AudioClip = undefined!;

    @property(cc.AudioClip)
    private splatAudio: cc.AudioClip = undefined!;

    @property(cc.AudioClip)
    private speedBoostAudio: cc.AudioClip = undefined!;

    @property(cc.AudioClip)
    private shockAudio: cc.AudioClip = undefined!;

    @property
    private overdriveSpeedMultiplier: number = 5;

    @property(cc.SpriteFrame)
    private normalSpriteFrame: cc.SpriteFrame = undefined!;

    @property(cc.SpriteFrame)
    private overdriveSpriteFrame: cc.SpriteFrame = undefined!;

    @property(cc.Node)
    private touchTarget: cc.Node = undefined!;

    // --- Internal State Tracking (Not visible in Inspector) ---
    private accLeft: boolean = false;
    private accRight: boolean = false;
    private xSpeed: number = 0;
    private isStunned: boolean = false;
    private isOverdrive: boolean = false;
    private speedModifier: number = 1.0;
    private trailTimer: number = 0;
    private trailInterval: number = 0.05;
    private playerGroundY: number = 0;

    // Marked public if accessed by other scripts (like Portal), otherwise private
    private isJumping: boolean = false;
    public isKnockedBack: boolean = false;
    public isTeleportCooldown: boolean = false;
    public isMovementLocked: boolean = false;

    private keyLeft: boolean = false;
    private keyRight: boolean = false;
    private touchLeft: boolean = false;
    private touchRight: boolean = false;
    private speedBoostEffectId: number = -1;
    private shockEffectId: number = -1;
    private hasEffect: boolean = false;

    private activeJumpTween: cc.Tween = null!;
    private lightningTween: cc.Tween = null!;

    private groundY: number = 0;
    private leftBorder: number = 0;
    private rightBorder: number = 0;
    public setUpBoundaries(groundY: number, leftBorder: number, rightBorder: number) {
        this.groundY = groundY;
        this.leftBorder = leftBorder;
        this.rightBorder = rightBorder;
    }

    public getJumpHeight() {
        return this.baseJumpHeight;
    }

    protected onLoad(): void {
        // Start the infinite looping jump animation
        this.playerGroundY = this.groundY + this.node.height / 2;
        this.startDefaultJumpLoop();

        // Initialize movement state flags and initial speed
        this.accLeft = false;
        this.accRight = false;
        this.xSpeed = 0;

        // For speed modifier
        this.isStunned = false;
        this.isOverdrive = false;
        this.speedModifier = 1.0;
        this.trailTimer = 0;
        this.trailInterval = 0.05;

        this.isTeleportCooldown = false;
        this.isMovementLocked = false;
        this.setUpListners();
    }

    private setUpListners() {
        // Register Keyboard listeners
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);

        // Register Touch Listeners
        let target = this.touchTarget || this.node; // fallback to self if not assigned
        this.touchTarget = target;

        target.on(cc.Node.EventType.TOUCH_START, this.onTouchChange, this);
        target.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchChange, this);
        target.on(cc.Node.EventType.TOUCH_END, this.onTouchChange, this);
        target.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchChange, this);
    }

    protected update(dt: number): void {
        // Pause check
        if (cc.director.getScheduler().getTimeScale() === 0) return;

        // For Lightning strike
        if (this.isStunned) {
            this.xSpeed = 0; // Lock the slime from moving laterally
            return;
        }

        // For Overdrive speed
        if (this.isOverdrive) {
            this.trailTimer += dt;
            if (this.trailTimer >= this.trailInterval) {
                this.trailTimer = 0;
                this.spawnFlashGhost(); // spawn every interval
            }
        }

        this.calculateAndSetSpeed(dt);
    }

    private calculateAndSetSpeed(dt: number) {
        // Calculate new velocity based on current input acceleration
        if (this.accLeft) {
            this.xSpeed -= this.accel * this.speedModifier * dt;
        } else if (this.accRight) {
            this.xSpeed += this.accel * this.speedModifier * dt;
        }

        let currMaxSpeed = this.maxMoveSpeed * this.speedModifier;

        // Clamp velocity so it does not exceed max move speed limits
        if (Math.abs(this.xSpeed) > currMaxSpeed && !this.isKnockedBack) {
            this.xSpeed = currMaxSpeed * Math.sign(this.xSpeed);
        }

        // Apply calculated speed to update player horizontal position
        this.node.x += this.xSpeed * dt;

        // Clamp position and reset momentum if player hits an edge wall
        if (this.node.x < this.leftBorder) {
            this.node.x = this.leftBorder;
            this.xSpeed = 0;
        } else if (this.node.x > this.rightBorder) {
            this.node.x = this.rightBorder;
            this.xSpeed = 0;
        }
    }

    protected onDestroy(): void {
        // Unregister global keyboard listeners to prevent memory leaks
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);

        if (this.touchTarget) {
            this.touchTarget.off(cc.Node.EventType.TOUCH_START, this.onTouchChange, this);
            this.touchTarget.off(cc.Node.EventType.TOUCH_MOVE, this.onTouchChange, this);
            this.touchTarget.off(cc.Node.EventType.TOUCH_END, this.onTouchChange, this);
            this.touchTarget.off(cc.Node.EventType.TOUCH_CANCEL, this.onTouchChange, this);
        }
    }

    protected onKeyDown(event: any): void {
        switch (event.keyCode) {
            case cc.macro.KEY.a:
            case cc.macro.KEY.left:
                this.keyLeft = true;
                break;
            case cc.macro.KEY.d:
            case cc.macro.KEY.right:
                this.keyRight = true;
                break;
            case cc.macro.KEY.space:
                this.triggerJump();
                break;
        }
        this.recomputeMovement();
    }

    protected onKeyUp(event: any): void {
        switch (event.keyCode) {
            case cc.macro.KEY.a:
            case cc.macro.KEY.left:
                this.keyLeft = false;
                break;
            case cc.macro.KEY.d:
            case cc.macro.KEY.right:
                this.keyRight = false;
                break;
        }
        this.recomputeMovement();
    }

    protected onTouchChange(event: any): void {
        let screenWidth = cc.view.getVisibleSize().width;

        if (
            event.type === cc.Node.EventType.TOUCH_END ||
            event.type === cc.Node.EventType.TOUCH_CANCEL
        ) {
            // Finger lifted — clear both, no stale position re-read
            this.touchLeft = false;
            this.touchRight = false;
        } else {
            let x = event.touch.getLocation().x;
            this.touchLeft = x < screenWidth / 2;
            this.touchRight = x >= screenWidth / 2;
        }

        this.recomputeMovement();
    }

    private recomputeMovement(): void {
        if (this.isMovementLocked) {
            this.accLeft = false;
            this.accRight = false;
            return;
        }
        this.accLeft = this.keyLeft || this.touchLeft;
        this.accRight = this.keyRight || this.touchRight;
    }

    // Jumping mechanics
    private startDefaultJumpLoop() {
        let duration = this.baseJumpHeight / this.jumpSpeed;
        if (this.activeJumpTween) {
            this.activeJumpTween.stop();
        }

        let targetPeakY = this.playerGroundY + this.baseJumpHeight;
        this.activeJumpTween = this.runJumpAction(targetPeakY, duration);
        this.activeJumpTween.start();
    }

    public triggerJump(): void {
        if (this.isJumping) return;
        this.isJumping = true;

        if (this.activeJumpTween) {
            this.activeJumpTween.stop();
        }

        // Recalculate new height
        let currentY = this.node.position.y;
        let extraBoostHeight = this.baseJumpHeight * 0.8;
        let targetPeakY = currentY + extraBoostHeight;

        let distanceToTravel = targetPeakY - currentY;
        let dynamicDuration = distanceToTravel / this.jumpSpeed;

        this.activeJumpTween = this.runJumpAction(targetPeakY, dynamicDuration);
        this.activeJumpTween.start();
    }

    private runJumpAction(targetY: number, duration: number): cc.Tween {
        // Moves up while stretching tall
        let jumpUp = cc
            .tween()
            .parallel(
                cc.tween().to(duration, { y: targetY }, { easing: "sineOut" }),
                cc.tween().to(duration * 0.3, { scaleX: 0.75, scaleY: 1.2 }, { easing: "quadOut" })
            );

        // Falls down while relaxing back to normal shape
        let jumpDown = cc
            .tween()
            .parallel(
                cc.tween().to(duration, { y: this.playerGroundY }, { easing: "sineIn" }),
                cc.tween().to(duration, { scaleX: 1.0, scaleY: 1.0 }, { easing: "quadIn" })
            );

        // Landing impact animation
        let landImpact = cc
            .tween()
            .sequence(
                cc.tween().to(0.05, { scaleX: 1.3, scaleY: 0.6 }, { easing: "sineOut" }),
                cc.tween().to(0.02, { scaleX: 1.0, scaleY: 1.0 }, { easing: "bounceOut" })
            );

        // Sequence actions together
        return cc
            .tween(this.node)
            .sequence(jumpUp, jumpDown, landImpact)
            .call(() => {
                this.isJumping = false;
                this.playJumpSound();
                // Loop back to default jump
                this.startDefaultJumpLoop();
            });
    }

    private playJumpSound(): void {
        // Play jump sound effect via audio engine instances
        if (this.jumpAudio) {
            cc.audioEngine.playEffect(this.jumpAudio, false);
        }
    }

    public playDeathAnimation(groundY: number, onAnimationComplete: Function): void {
        // Stop the infinite jumping loop immediately
        this.node.stopAllActions();

        // Calculate the drop distance
        let currentY = this.node.y;
        let fallDistance = Math.abs(currentY - groundY);
        let fallDuration = fallDistance / 1500;

        // Play a dramatic flattening, spinning, and shrinking effect and audio
        if (this.splatAudio) {
            cc.audioEngine.playEffect(this.splatAudio, false);
        }

        cc.tween(this.node)
            // Phase A: Drop straight down to the floor Y axis line
            .to(fallDuration, { y: groundY }, { easing: "quadIn" })

            // Phase B: Dramatic Flattening (Splats wide and short against the floor)
            .to(0.2, { scaleX: 1.6, scaleY: 0.15 }, { easing: "sineOut" })

            // Phase C: Melt away horizontally into nothingness
            .parallel(
                cc.tween().to(0.25, { scaleX: 0.0, scaleY: 0.0 }, { easing: "quadIn" }),
                cc.tween().to(0.25, { opacity: 0 })
            )
            .call(() => {
                // Trigger the callback function once the animation finishes
                if (onAnimationComplete) {
                    onAnimationComplete();
                }
            })
            .start();
    }

    // Charger effects
    public applyKnockback(vx: number, dy: number): void {
        this.isKnockedBack = true;

        // Visual stun
        this.node.color = cc.Color.BLUE;

        // Get Knockbacked
        this.xSpeed = vx;

        if (this.activeJumpTween) {
            this.activeJumpTween.stop();
        }

        // Recalculate new height
        let currentY = this.node.position.y;
        let targetPeakY = currentY + Math.abs(dy);
        let distanceToTravel = targetPeakY - currentY;
        let dynamicDuration = distanceToTravel / this.jumpSpeed;

        this.activeJumpTween = this.runJumpAction(targetPeakY, dynamicDuration);
        this.activeJumpTween.start();

        this.scheduleOnce(() => {
            this.isKnockedBack = false;
            cc.tween(this.node)
                .repeat(6, cc.tween().by(0.05, { x: 12 }).by(0.05, { x: -12 }))
                .start();
            this.xSpeed = 0;
            this.isMovementLocked = true;
        }, 0.5);

        this.scheduleOnce(() => {
            this.node.color = cc.Color.WHITE;
            this.isMovementLocked = false;
        }, 2.0);
    }

    // Lightning effects
    public applyLightningEffect(statusType: string, duration: number): void {
        // To ensure player does not repeatedly get hit by lightning
        if (this.hasEffect) return;

        // Clear old power-up timelines on this target to prevent conflicts
        if (this.lightningTween) {
            this.lightningTween.stop();
            this.lightningTween = null!;
        }
        // Reset base states cleanly
        this.isStunned = false;
        this.speedModifier = 1.0;
        this.node.color = cc.Color.WHITE;
        this.hasEffect = true;

        let sprite = this.getComponent(cc.Sprite);
        sprite.spriteFrame = this.normalSpriteFrame;

        if (statusType === "OVERDRIVE") {
            // Speed boost
            this.playOverdriveAnimation(duration, sprite);
        } else if (statusType === "STUN") {
            // Stunned effect
            this.playStunAnimation(duration);
        }
    }

    private playOverdriveAnimation(duration: number, sprite: cc.Sprite) {
        this.isOverdrive = true;
        this.speedModifier = this.overdriveSpeedMultiplier;
        this.node.color = cc.Color.YELLOW;
        if (sprite && this.overdriveSpriteFrame) {
            sprite.spriteFrame = this.overdriveSpriteFrame;
        }
        if (this.speedBoostAudio) {
            this.speedBoostEffectId = cc.audioEngine.playEffect(this.speedBoostAudio, false);
        }

        this.lightningTween = cc
            .tween(this.node)
            .delay(duration)
            .call(() => {
                this.isOverdrive = false;
                this.speedModifier = 1.0;
                this.node.color = cc.Color.WHITE;
                if (sprite && this.normalSpriteFrame) {
                    sprite.spriteFrame = this.normalSpriteFrame;
                }
                if (this.speedBoostEffectId !== -1) {
                    cc.audioEngine.stopEffect(this.speedBoostEffectId);
                    this.speedBoostEffectId = -1;
                }
            })
            .delay(1.0)
            .call(() => {
                this.hasEffect = false; // To prevent multiple strikes at one go
            })
            .start();
    }

    private playStunAnimation(duration: number) {
        this.isStunned = true;
        this.node.color = cc.Color.BLUE;
        if (this.shockAudio) {
            this.shockEffectId = cc.audioEngine.playEffect(this.shockAudio, false);
        }

        // Visual juice: rapid shudder vibration effect
        cc.tween(this.node)
            .repeat(6, cc.tween().by(0.05, { x: 12 }).by(0.05, { x: -12 }))
            .start();

        // Auto release gate timer
        this.lightningTween = cc
            .tween(this.node)
            .delay(duration)
            .call(() => {
                this.isStunned = false;
                this.node.color = cc.Color.WHITE;
                if (this.shockEffectId !== -1) {
                    cc.audioEngine.stopEffect(this.shockEffectId);
                    this.shockEffectId = -1;
                }
            })
            .delay(1.0)
            .call(() => {
                this.hasEffect = false; // To prevent multiple strikes at one go
            })
            .start();
    }

    private spawnFlashGhost(): void {
        // Create a brand new blank node for the ghost
        let ghost = new cc.Node("FlashGhost");
        this.node.parent.addChild(ghost);

        // Copy the exact position, scale, anchor, and rotation of your player slime
        ghost.setPosition(this.node.getPosition());
        ghost.scaleX = this.node.scaleX;
        ghost.scaleY = this.node.scaleY;
        ghost.anchorX = this.node.anchorX;
        ghost.anchorY = this.node.anchorY;
        ghost.angle = this.node.angle;

        // Copy the graphic visual image from the player sprite component
        let playerSprite = this.getComponent(cc.Sprite);
        if (playerSprite && playerSprite.spriteFrame) {
            let ghostSprite = ghost.addComponent(cc.Sprite);
            ghostSprite.sizeMode = cc.Sprite.SizeMode.CUSTOM;
            ghostSprite.spriteFrame = playerSprite.spriteFrame;
        }

        ghost.width = this.node.width;
        ghost.height = this.node.height;
        ghost.color = cc.Color.RED;
        ghost.opacity = 50; // Start semi-transparent

        // Fade the ghost out into nothingness quickly
        cc.tween(ghost)
            .to(0.25, { opacity: 0, scaleX: this.node.scaleX * 0.8 })
            .call(() => {
                ghost.destroy(); // Completely wipe from engine memory
            })
            .start();
    }
}
