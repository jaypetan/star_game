const { ccclass, property } = cc._decorator;

@ccclass
export default class MainMenu extends cc.Component {
    @property(cc.Node)
    private menuContent: cc.Node = undefined!;

    @property
    private fadeDuration: number = 0.5;

    @property(cc.AudioClip)
    private startMenuAudio: cc.AudioClip = undefined!;

    @property([cc.Node])
    private nodeList: cc.Node[] = [];

    private currentIndex: number = 0;

    public onPlayButtonPressed(event: cc.Event, gameSceneName: string): void {
        // Fallback: Change scenes immediately if no UI container is linked
        if (!this.menuContent) {
            cc.director.loadScene(gameSceneName);
            return;
        }

        // Play audio if available
        if (this.startMenuAudio) {
            cc.audioEngine.playEffect(this.startMenuAudio, false);
        }

        // Smoothly fade the menu UI group to fully transparent
        cc.tween(this.menuContent)
            .to(this.fadeDuration, { opacity: 0 })
            .call(() => {
                cc.director.loadScene(gameSceneName);
            })
            .start();
    }

    public nextNode(): void {
        if (this.nodeList.length === 0) return;

        // Remove active node
        if (this.nodeList[this.currentIndex]) {
            this.nodeList[this.currentIndex].active = false;
        }

        // Ensure the number wraps around or stays within valid bounds
        this.currentIndex = (this.currentIndex + 1) % this.nodeList.length;

        // Enable new node
        if (this.nodeList[this.currentIndex]) {
            this.nodeList[this.currentIndex].active = true;
        }
    }
}
