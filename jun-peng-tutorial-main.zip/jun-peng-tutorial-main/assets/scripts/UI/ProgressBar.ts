const { ccclass, property } = cc._decorator;

@ccclass
export default class ProgressBar extends cc.Component {
    private timer: number = 0;
    private starDuration: number = 0;

    public setProgressBar(timer: number, starDuration: number) {
        this.timer = timer;
        this.starDuration = starDuration;
        this.incrementProgress();
    }

    private incrementProgress() {
        // Calculate the ratio percentage remaining for time left
        let progressRatio = 1 - this.timer / this.starDuration;
        this.getComponent(cc.ProgressBar).progress = Math.max(0, progressRatio);

        // Change color of bar accordingly
        if (progressRatio < 0.3) {
            this.node.getChildByName("bar").color = cc.Color.RED;
        } else {
            this.node.getChildByName("bar").color = cc.Color.GREEN;
        }
    }
}
