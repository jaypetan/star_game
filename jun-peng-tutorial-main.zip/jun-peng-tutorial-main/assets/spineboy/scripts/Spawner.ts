const { ccclass, property } = cc._decorator;

@ccclass
export default class Spawner extends cc.Component {
    @property(cc.Node)
    private starNode: cc.Node = undefined!;

    @property
    private blobDropChance: number = 0.8;

    @property
    private spawnInterval: number = 3.0;

    @property
    private maxNumOfBlobs: number = 10.0;

    @property
    private maxNumOfAmmo: number = 5.0;

    private timer: number = 0;
    private stopSpawner = false;

    private getAndSetBlob!: (spawnPos: cc.Vec2, parentNode: cc.Node) => cc.Node;
    private getAndSetAmmo!: (spawnPos: cc.Vec2, parentNode: cc.Node) => cc.Node;
    private recycleBlob!: (node: cc.Node) => void;
    private recycleAmmo!: (node: cc.Node) => void;
    private recycleBullet!: (node: cc.Node) => void;
    private playExplosion!: (explosionPos: cc.Vec2, parent: cc.Node) => null;
    private getActiveBullets!: () => { node: cc.Node; direction: number; timer: number }[];

    private groundY: number = undefined!;
    private minX: number = undefined!;
    private maxX: number = undefined!;
    private gravity: number = undefined!;

    public initSpawner(
        boundaries: { groundY: number; minX: number; maxX: number; gravity: number },
        getAndSetBlob: (spawnPos: cc.Vec2, parentNode: cc.Node) => cc.Node,
        getAndSetAmmo: (spawnPos: cc.Vec2, parentNode: cc.Node) => cc.Node,
        recycleBlob: (node: cc.Node) => void,
        recycleAmmo: (node: cc.Node) => void,
        recycleBullet: (node: cc.Node) => void,
        playExplosion: (explosionPos: cc.Vec2, parent: cc.Node) => null,
        getActiveBullets: () => { node: cc.Node; direction: number; timer: number }[]
    ): void {
        // Set boundaries
        this.groundY = boundaries.groundY;
        this.minX = boundaries.minX;
        this.maxX = boundaries.maxX;
        this.gravity = boundaries.gravity;

        // Set functions
        this.getAndSetBlob = getAndSetBlob;
        this.getAndSetAmmo = getAndSetAmmo;
        this.recycleBlob = recycleBlob;
        this.recycleAmmo = recycleAmmo;
        this.recycleBullet = recycleBullet;
        this.playExplosion = playExplosion;
        this.getActiveBullets = getActiveBullets;
    }

    // Track the current blobs and ammo
    private activeAmmoBoxes: cc.Node[] = [];
    private activeBlobs: cc.Node[] = [];

    public getActiveAmmoBoxes() {
        return this.activeAmmoBoxes;
    }
    public removeBulletFromActiveAmmoBoxes(bulletIndex: number) {
        this.activeAmmoBoxes.splice(bulletIndex, 1);
    }
    public getActiveBlobs() {
        return this.activeBlobs;
    }
    public removeBlobFromActiveBlobs(blobIndex: number) {
        this.activeBlobs.splice(blobIndex, 1);
    }

    protected onLoad(): void {
        this.stopSpawner = false;
    }

    protected update(dt: number): void {
        if (!this.starNode || this.stopSpawner) return;

        this.timer += dt;

        if (this.timer >= this.spawnInterval) {
            this.timer = 0;
            if (Math.random() < this.blobDropChance) {
                this.spawnBlob();
            } else {
                this.spawnAmmo();
            }
        }
    }

    private spawnAmmo(exactSpawnPos?: cc.Vec2): void {
        if (this.activeAmmoBoxes.length >= this.maxNumOfAmmo) return;

        // Get the bounding box of your boundary node in world/parent coordinates
        let width = this.node.width;
        let centerX = this.node.x;
        let randomX = centerX + (Math.random() - 0.5) * width;
        let spawnPos = exactSpawnPos ? exactSpawnPos : cc.v2(randomX, this.node.y);

        let ammoNode = this.getAndSetAmmo(spawnPos, this.node.parent);
        let ammoScript = ammoNode.getComponent("AmmoPickup");
        if (ammoScript) {
            ammoScript.initAmmo();
            ammoScript.setGroundY(this.groundY);
        }

        this.activeAmmoBoxes.push(ammoNode);
    }

    private spawnBlob(): void {
        if (this.activeBlobs.length >= this.maxNumOfBlobs) return;

        // Get the bounding box of your boundary node in world/parent coordinates
        let width = this.node.width;
        let centerX = this.node.x;
        let randomX = centerX + (Math.random() - 0.5) * width;
        let spawnPos = cc.v2(randomX, this.node.y);

        let blobNode = this.getAndSetBlob(spawnPos, this.node.parent);
        let blobScript = blobNode.getComponent("BlobEnemy") as any;
        if (blobScript) {
            // Initialize references
            blobScript.setStarNode(this.starNode);
            blobScript.initBlob(
                { groundY: this.groundY, minX: this.minX, maxX: this.maxX, gravity: this.gravity },
                (node: cc.Node) => this.recycleBullet(node),
                (node: cc.Node) => this.recycleBlob(node),
                (explosionPos: cc.Vec2, parent: cc.Node) =>
                    this.playExplosion(explosionPos, parent),
                (exactSpawnPos: cc.Vec2) => this.spawnAmmo(exactSpawnPos),
                () => this.stopSpawningAndDestroyEverything(),
                () => this.getActiveBlobs(),
                (blobIndex: number) => this.removeBlobFromActiveBlobs(blobIndex),
                () => this.getActiveBullets()
            );
        }

        // Add to spawner tracking list
        this.activeBlobs.push(blobNode);
    }

    public stopSpawningAndDestroyEverything() {
        this.stopSpawner = true;
        this.destroyAllBlobs();
        this.destroyAllAmmoBoxes();
    }

    private destroyAllBlobs(): void {
        for (const blobNode of this.activeBlobs) {
            if (blobNode && cc.isValid(blobNode)) {
                let blobComp = blobNode.getComponent("BlobEnemy") as any;
                if (blobComp && typeof blobComp.selfImplode === "function") {
                    blobComp.selfImplode();
                }
            }
        }
        this.activeBlobs.length = 0;
    }

    private destroyAllAmmoBoxes(): void {
        for (const ammoBox of this.activeAmmoBoxes) {
            if (ammoBox && cc.isValid(ammoBox)) {
                this.recycleAmmo(ammoBox);
            }
        }
        this.activeAmmoBoxes.length = 0;
    }
}
