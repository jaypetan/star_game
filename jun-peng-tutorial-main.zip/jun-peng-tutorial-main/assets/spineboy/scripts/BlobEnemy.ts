const { ccclass, property } = cc._decorator;

@ccclass
export default class BlobEnemy extends cc.Component {
    // List of all active blobs
    public static activeBlobs: BlobEnemy[] = [];

    @property(cc.Node)
    private visualNode: cc.Node = undefined!;

    @property(cc.AudioClip)
    private jumpAudio: cc.AudioClip = undefined!;

    @property(cc.AudioClip)
    private splatAudio: cc.AudioClip = undefined!;

    @property
    private detectionRange: number = 300; // Max distance to trigger the calculated leap to star

    @property
    public jumpLeap: number = 600; // How high above its current position the jump arc should peak

    @property
    private jumpSpeedX: number = 100; // How far the blob leaps horizontally

    @property
    private jumpSpeedY: number = 400; // How high the blob leaps vertically

    @property
    private jumpCooldown: number = 2; // How many seconds between each jump

    @property
    private dropChance: number = 0.5; // How likely the blob will drop a bullet

    @property(cc.Prefab)
    private ammoPrefab: cc.Prefab = undefined!;

    private timer: number = 0;
    private isJumping: boolean = false;
    private isFalling: boolean = false;
    public isSpawning: boolean = true;

    private velocityX: number = 0;
    private velocityY: number = 0;
    private spawnDropSpeed: number = 800;

    private starNode: cc.Node = undefined!;
    public setStarNode(node: cc.Node) {
        this.starNode = node;
    }

    private recycleBullet!: (node: cc.Node) => void;
    private recycleBlob!: (node: cc.Node) => void;
    private playExplosion!: (explosionPos: cc.Vec2, parent: cc.Node) => null;
    private spawnAmmo!: (exactSpawnPosition: cc.Vec2) => void;
    private stopSpawningAndDestroyEverything!: () => void;
    private getActiveBlobs!: () => cc.Node[];
    private removeBlobFromActiveBlobs!: (blobIndex: number) => void;
    private getActiveBullets!: () => { node: cc.Node; direction: number; timer: number }[];

    private groundY: number = undefined!;
    private minX: number = undefined!;
    private maxX: number = undefined!;
    private gravity: number = undefined!;

    public initBlob(
        bounds: { groundY: number; minX: number; maxX: number; gravity: number },
        recycleBullet: (node: cc.Node) => void,
        recycleBlob: (node: cc.Node) => void,
        playExplosion: (explosionPos: cc.Vec2, parent: cc.Node) => null,
        spawnAmmo: (explosionPos: cc.Vec2) => void,
        stopSpawningAndDestroyEverything: () => void,
        getActiveBlobs: () => cc.Node[],
        removeBlobFromActiveBlobs: (blobIndex: number) => void,
        getActiveBullets: () => { node: cc.Node; direction: number; timer: number }[]
    ) {
        // Reset variables
        this.isSpawning = true;
        this.isJumping = false;
        this.isFalling = false;

        // Set boundaries
        this.groundY = bounds.groundY;
        this.minX = bounds.minX;
        this.maxX = bounds.maxX;
        this.gravity = bounds.gravity;

        // Set functions
        this.recycleBullet = recycleBullet;
        this.recycleBlob = recycleBlob;
        this.playExplosion = playExplosion;
        this.spawnAmmo = spawnAmmo;
        this.stopSpawningAndDestroyEverything = stopSpawningAndDestroyEverything;
        this.getActiveBlobs = getActiveBlobs;
        this.removeBlobFromActiveBlobs = removeBlobFromActiveBlobs;
        this.getActiveBullets = getActiveBullets;
    }

    protected update(dt: number): void {
        if (!this.starNode || !cc.isValid(this.starNode)) return;

        if (this.isSpawning) {
            this.handleSpawningState(dt);
        } else {
            this.isJumping ? this.handleJumpingState(dt) : this.handleGroundedState(dt);
            this.applyMovementandBoundary(dt);
            this.checkCollider();
        }
    }

    // State Management
    private handleSpawningState(dt: number) {
        this.velocityY -= this.spawnDropSpeed * dt;
        this.node.y += this.velocityY * dt;

        // Check if it has hit the floor
        if (this.node.y <= this.groundY) {
            this.landOnFloor();
            this.playSlamAndPopAnimation();
        }
    }

    private handleJumpingState(dt: number) {
        this.velocityY -= this.gravity * dt;

        // Animation on air
        if (this.velocityY < 0 && !this.isFalling) {
            this.isFalling = true;
            this.playFallNormal();
        }

        // Animation when landed
        if (this.node.y <= this.groundY) {
            this.landOnFloor();
            this.playLandImpact();
        }
    }

    private landOnFloor() {
        this.node.y = this.groundY;
        this.velocityY = 0;
        this.velocityX = 0;
        this.isSpawning = false;
        this.isJumping = false;
        this.isFalling = false;
    }

    private handleGroundedState(dt: number) {
        // Increase the timer only when grounded
        this.timer += dt;

        // When the timer reaches the cooldown, jump and reset the timer
        if (this.timer >= this.jumpCooldown) {
            this.executeJump();
            this.playJumpStretch();
            this.timer = 0;
        }
    }

    private executeJump() {
        this.node.scaleX = this.starNode.x > this.node.x ? -1 : 1;

        let distance = cc.Vec2.distance(this.node.position, this.starNode.position);
        distance <= this.detectionRange
            ? this.leapTowardStar() // Targetted jump
            : this.jumpTowardPlayer(); // Default
    }

    private applyMovementandBoundary(dt: number) {
        // Update movement of blob
        let pos = this.node.position;
        pos.x += this.velocityX * dt;
        pos.y += this.velocityY * dt;

        // Wall Boundary
        if (pos.x < this.minX) {
            pos.x = this.minX;
            this.velocityX = 0; // Stop horizontal momentum on hit
        } else if (pos.x > this.maxX) {
            pos.x = this.maxX;
            this.velocityX = 0; // Stop horizontal momentum on hit
        }

        // Prevent falling through the floor
        if (pos.y < this.groundY) {
            pos.y = this.groundY;
        }

        this.node.position = pos;
    }

    // Collider checking
    private checkCollider() {
        this.checkStarCollider();
        this.checkBulletCollider();
    }

    private checkStarCollider() {
        if (this.starNode && this.isCloseTo(this.starNode, 70)) {
            // Play Explosion
            let explosionPos = cc.v2(this.node.position.x, this.node.position.y);
            this.playExplosion(explosionPos, this.node.parent);

            // Destroy star node and itself
            this.stopSpawningAndDestroyEverything();
            this.starNode.destroy();
            this.selfImplode();
        }
    }

    private checkBulletCollider() {
        let activeBullets = this.getActiveBullets();

        for (let i = activeBullets.length - 1; i >= 0; i--) {
            let bulletNode = activeBullets[i].node;

            if (bulletNode && this.isCloseTo(bulletNode, 40)) {
                if (Math.random() <= this.dropChance && this.ammoPrefab) {
                    let spawnPos = cc.v2(this.node.position.x, this.node.position.y);
                    this.spawnAmmo(spawnPos); // Random chance to drop ammo
                }

                this.recycleBullet(bulletNode);
                this.selfImplode();
                break;
            }
        }
    }

    // Animation
    private playSlamAndPopAnimation(): void {
        if (!this.visualNode) return;
        cc.Tween.stopAllByTarget(this.visualNode);

        // Instantly force it flat like a pancake on impact, then pop back up elastically
        cc.tween(this.visualNode)
            .to(0.05, { scaleX: 2.0, scaleY: 0.4 }, { easing: "sineOut" })
            .to(0.15, { scaleX: 0.7, scaleY: 1.3 }, { easing: "quadOut" })
            .to(0.2, { scaleX: 1.0, scaleY: 1.0 }, { easing: "bounceOut" })
            .start();
    }

    private playJumpStretch(): void {
        if (!this.visualNode) return;
        cc.Tween.stopAllByTarget(this.visualNode);

        if (this.jumpAudio) {
            cc.audioEngine.playEffect(this.jumpAudio, false);
        }

        cc.tween(this.visualNode)
            .to(0.12, { scaleX: 0.75, scaleY: 1.25 }, { easing: "quadOut" })
            .start();
    }

    private playFallNormal(): void {
        if (!this.visualNode) return;
        cc.Tween.stopAllByTarget(this.visualNode);

        cc.tween(this.visualNode)
            .to(0.25, { scaleX: 0.9, scaleY: 1.1 }, { easing: "sineIn" })
            .start();
    }

    private playLandImpact(): void {
        if (!this.visualNode) return;
        cc.Tween.stopAllByTarget(this.visualNode);

        cc.tween(this.visualNode)
            .to(0.08, { scaleX: 1.4, scaleY: 0.6 }, { easing: "sineOut" })
            .to(0.25, { scaleX: 1.0, scaleY: 1.0 }, { easing: "bounceOut" })
            .start();
    }

    private jumpTowardPlayer(): void {
        this.isJumping = true;
        this.isFalling = false;

        let directionX = this.starNode.x > this.node.x ? 1 : -1;
        this.velocityX = this.jumpSpeedX * directionX;
        this.velocityY = this.jumpSpeedY;
    }

    private leapTowardStar(): void {
        this.isJumping = true;
        this.isFalling = false;

        let starPos = cc.v2(this.starNode.x, this.starNode.y + 20);
        let currPos = cc.v2(this.node.x, this.node.y);
        let direction = starPos.sub(currPos).normalize();

        let directVel = direction.mul(this.jumpLeap);
        this.velocityX = directVel.x;
        this.velocityY = directVel.y;
    }

    public selfImplode(): void {
        // Play Explosion
        let explosionPos = cc.v2(this.node.position.x, this.node.position.y);
        this.playExplosion(explosionPos, this.node.parent);

        if (this.splatAudio) {
            cc.audioEngine.playEffect(this.splatAudio, false);
        }

        setTimeout(() => {
            if (cc.isValid(this.node)) {
                let activeBlobs = this.getActiveBlobs();
                let index = activeBlobs.indexOf(this.node);
                this.removeBlobFromActiveBlobs(index);
                this.recycleBlob(this.node);
            }
        }, 0);
    }

    private isCloseTo(targetNode: cc.Node, threshold: number): boolean {
        if (!targetNode || !cc.isValid(targetNode)) return false;

        // Calculate Euclidean distance between the center anchor points
        let distance = cc.Vec2.distance(this.node.position, targetNode.position);
        return distance <= threshold;
    }
}
