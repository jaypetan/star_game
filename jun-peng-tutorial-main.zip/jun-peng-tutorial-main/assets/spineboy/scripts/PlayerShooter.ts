const { ccclass, property } = cc._decorator;

@ccclass
export default class PlayerShooter extends cc.Component {
    @property(cc.AudioClip)
    private shootAudio: cc.AudioClip = undefined!;

    @property(cc.AudioClip)
    private emptyAudio: cc.AudioClip = undefined!;

    @property
    private bulletSpeed: number = 800;

    @property
    private maxAmmo: number = 5;

    @property(cc.Label)
    private bulletCountLabel: cc.Label = undefined!;

    @property(cc.Label)
    private messageLabel: cc.Label = undefined!;

    private currentAmmo: number = 5;

    @property
    private pickupRadius: number = 100;

    private activeBullets: { node: cc.Node; direction: number; timer: number }[] = [];
    public getActiveBullets() {
        return this.activeBullets;
    }

    private getAndSetBullet!: (spawnPos: cc.Vec2, parentNode: cc.Node) => cc.Node;
    private recycleBullet!: (node: cc.Node) => void;
    private recycleAmmo!: (node: cc.Node) => void;
    public setNodePools(
        getAndSetBullet: (spawnPos: cc.Vec2, parentNode: cc.Node) => cc.Node,
        recycleBullet: (node: cc.Node) => void,
        recycleAmmo: (node: cc.Node) => void
    ) {
        this.getAndSetBullet = getAndSetBullet;
        this.recycleBullet = recycleBullet;
        this.recycleAmmo = recycleAmmo;
    }

    private getActiveAmmoBoxes!: () => cc.Node[];
    private removeBulletFromActiveAmmoBoxes!: (bulletIndex: number) => void;
    public setActiveAmmoBoxesFunctions(
        getActiveAmmoBoxes: () => cc.Node[],
        removeBulletFromActiveAmmoBoxes: (bulletIndex: number) => void
    ) {
        this.getActiveAmmoBoxes = getActiveAmmoBoxes;
        this.removeBulletFromActiveAmmoBoxes = removeBulletFromActiveAmmoBoxes;
    }

    protected onLoad(): void {
        this.currentAmmo = this.maxAmmo;
        this.updateBulletUI();
    }

    protected update(dt: number): void {
        this.checkAmmoPickups();

        // Loop through all active bullets and move them manually every frame
        for (let i = this.activeBullets.length - 1; i >= 0; i--) {
            let item = this.activeBullets[i];
            item.timer += dt;

            if (item.timer >= 0.3) {
                this.recycleBullet(item.node);
                this.activeBullets.splice(i, 1);
                continue;
            }

            // Move the bullet horizontally
            let pos = item.node.position;
            pos.x += this.bulletSpeed * item.direction * dt;
            item.node.position = pos;
        }
    }

    public shoot(): void {
        let playerScript = this.node.getComponent("SpineBoyPlayer");
        if (playerScript) {
            if (playerScript.isShooting) return;
            playerScript.playShootAnimation();
        }

        this.checkAndShootBullet();
    }

    private checkAndShootBullet() {
        if (this.currentAmmo > 0) {
            if (this.shootAudio) {
                cc.audioEngine.playEffect(this.shootAudio, false);
            }

            this.spawnBullet();
            this.currentAmmo--;
            this.updateBulletUI();
        } else {
            if (this.emptyAudio) {
                cc.audioEngine.playEffect(this.emptyAudio, false);
            }

            this.messageLabel.node.active = true;
            this.messageLabel.string = "NO BULLETS LEFT";
            this.scheduleOnce(() => {
                this.messageLabel.string = "";
                this.messageLabel.node.active = false;
            }, 2);
            return;
        }
    }

    private spawnBullet() {
        // Pull bullet from the pool
        let direction = this.node.scaleX > 0 ? 1 : -1;
        let spawnOffsetX = 50 * direction; // So bullet spawn 50 px in front of gun
        let spawnPos = cc.v2(this.node.x + spawnOffsetX, this.node.y + 60);
        let bullet = this.getAndSetBullet(spawnPos, this.node.parent);

        let anim = bullet.getComponent(cc.Animation);
        if (anim) {
            anim.stop();
            anim.play("laser"); // Force play the animation from frame 0
        }

        this.activeBullets.push({
            node: bullet,
            direction: direction,
            timer: 0,
        });
    }

    private updateBulletUI(): void {
        if (this.bulletCountLabel) {
            this.bulletCountLabel.string = `x ${this.currentAmmo.toString().padStart(2, "0")}`;
        }
    }

    private checkAmmoPickups(): void {
        let activeAmmoBoxes = this.getActiveAmmoBoxes();
        if (activeAmmoBoxes === undefined) return;

        // Loop backwards so we can safely remove collected ammo boxes from the array
        for (let i = activeAmmoBoxes.length - 1; i >= 0; i--) {
            let ammoBox = activeAmmoBoxes[i];

            // Calculate distance between player and ammo box
            let distance = cc.Vec2.distance(this.node.position, ammoBox.position);
            if (distance < this.pickupRadius) {
                let ammoScript = ammoBox.getComponent("AmmoPickup");
                this.addAmmo(ammoScript.ammoReload);
                if (ammoScript && (ammoScript as any).pickupSound) {
                    cc.audioEngine.playEffect(ammoScript.pickupSound, false);
                }

                // Destroy the ammo box node and remove it from tracking
                this.recycleAmmo(ammoBox);
                this.removeBulletFromActiveAmmoBoxes(i);
            }
        }
    }

    public addAmmo(ammoReload: number): void {
        this.currentAmmo += ammoReload;
        this.updateBulletUI();
    }
}
