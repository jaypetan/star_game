import SpinePoolManager from "./SpinePoolManager";

const { ccclass, property } = cc._decorator;

@ccclass
export default class GameManager extends cc.Component {
    public static instance: GameManager = undefined!;
    @property(cc.Sprite)
    private pauseButtonSprite: cc.Sprite = undefined!;

    @property(cc.SpriteFrame)
    private pauseIcon: cc.SpriteFrame = undefined!;

    @property(cc.SpriteFrame)
    private playIcon: cc.SpriteFrame = undefined!;

    @property(cc.Label)
    private timerLabel: cc.Label = undefined!;

    @property(cc.Label)
    private highScoreLabel: cc.Label = undefined!;

    @property(cc.Node)
    private gameOverPanel: cc.Node = undefined!;

    @property(cc.Node)
    private ground: cc.Node = undefined!;

    @property(cc.Node)
    private leftBorder: cc.Node = undefined!;

    @property(cc.Node)
    private rightBorder: cc.Node = undefined!;

    @property(cc.Node)
    private spawner: cc.Node = undefined!;

    @property(cc.Node)
    private player: cc.Node = undefined!;

    private poolManager: SpinePoolManager = undefined!;

    @property(cc.Prefab)
    private explosionPrefab: cc.Prefab = undefined!;

    // Score tracking
    private highScore: number = 0;
    private elapsedTime: number = 0;
    private isPlaying: boolean = true;
    private isPaused: boolean = false;

    // Default boundaries
    public groundY = 0;
    public minX = -500;
    public maxX = 500;
    public gravity = 540;

    protected onLoad(): void {
        // Init game boundaries
        this.groundY = this.ground.position.y + 0.5 * this.ground.height;
        this.minX = this.leftBorder.position.x + 0.5 * this.leftBorder.width;
        this.maxX = this.rightBorder.position.x - 0.5 * this.rightBorder.width;

        // Load saved high score from local storage
        this.highScore = cc.sys.localStorage.getItem("spineboy_highscore") || 0;
        this.highScore = Number(this.highScore);
        this.updateHighScoreUI();

        // Ensure panels are hidden at startup
        if (this.gameOverPanel) this.gameOverPanel.active = false;

        // Reset game time scale
        cc.director.resume();

        // Initialize node pool
        let poolManager = (this.poolManager = this.node.getComponent("SpinePoolManager"));
        poolManager.initializeNodePools();
    }

    protected start(): void {
        // initialize spawner and player
        this.initSpawner();
        this.initPlayer();
    }

    private initSpawner() {
        // Initialize spawner references
        let spawnerScript = this.spawner.getComponent("Spawner");
        let playerShooterScript = this.player.getComponent("PlayerShooter");
        spawnerScript.initSpawner(
            {
                groundY: this.groundY,
                minX: this.minX,
                maxX: this.maxX,
                gravity: this.gravity,
            },
            (spawnPos: cc.Vec2, parentNode: cc.Node) =>
                this.poolManager.getAndSetBlob(spawnPos, parentNode),
            (spawnPos: cc.Vec2, parentNode: cc.Node) =>
                this.poolManager.getAndSetAmmo(spawnPos, parentNode),
            (node: cc.Node) => this.poolManager.recycleBlob(node),
            (node: cc.Node) => this.poolManager.recycleAmmo(node),
            (node: cc.Node) => this.poolManager.recycleBullet(node),
            (pos: cc.Vec2, parent: cc.Node) => this.playExplosion(pos, parent),
            () => playerShooterScript.getActiveBullets()
        );
    }

    private initPlayer() {
        // Initialize shooting and ammo references
        let playerShooterScript = this.player.getComponent("PlayerShooter");
        playerShooterScript.setNodePools(
            (spawnPos: cc.Vec2, parentNode: cc.Node) =>
                this.poolManager.getAndSetBullet(spawnPos, parentNode),
            (node: cc.Node) => this.poolManager.recycleBullet(node),
            (node: cc.Node) => this.poolManager.recycleAmmo(node)
        );
        let spawnerScript = this.spawner.getComponent("Spawner");
        playerShooterScript.setActiveAmmoBoxesFunctions(
            () => spawnerScript.getActiveAmmoBoxes(),
            (bulletIndex: number) => spawnerScript.removeBulletFromActiveAmmoBoxes(bulletIndex)
        );

        // Initialize movement references
        let playerMovementScript = this.player.getComponent("SpineBoyPlayer");
        playerMovementScript.initBoundaries(this.groundY, this.minX, this.maxX, this.gravity);
        playerMovementScript.initGameFunctions(
            () => this.triggerGameOver(),
            () => this.togglePause()
        );
    }

    protected update(dt: number): void {
        if (!this.isPlaying || this.isPaused) return;

        // Increment and format the timer
        this.elapsedTime += dt;
        if (this.timerLabel) {
            this.timerLabel.string = `Score: ${this.elapsedTime.toFixed(0)}`;
        }
    }

    // Explosion
    public playExplosion(spawnPos: cc.Vec2, parentNode: cc.Node): void {
        let explosion = cc.instantiate(this.explosionPrefab);
        explosion.parent = parentNode;
        explosion.setPosition(spawnPos);
    }

    // UI functions
    public togglePause(): void {
        if (!this.isPlaying) return;

        this.isPaused = !this.isPaused;
        this.isPaused ? cc.director.pause() : cc.director.resume();
        if (this.pauseButtonSprite) {
            this.pauseButtonSprite.spriteFrame = this.isPaused ? this.playIcon : this.pauseIcon;
        }
    }

    public triggerGameOver(): void {
        if (!this.isPlaying) return;
        this.isPlaying = false;

        // Check and save highscore
        if (this.elapsedTime > this.highScore) {
            this.highScore = this.elapsedTime;
            cc.sys.localStorage.setItem("spineboy_highscore", this.highScore);
            this.updateHighScoreUI();
        }

        // Show Game Over menu
        if (this.gameOverPanel) {
            this.gameOverPanel.active = true;
        }
    }

    private updateHighScoreUI(): void {
        if (this.highScoreLabel) {
            this.highScoreLabel.string = `Best: ${this.highScore.toFixed(0)}`;
        }
    }

    public restartGame(): void {
        // Reset time scale before reloading scene
        cc.director.resume();
        cc.director.loadScene("spineboy");
    }

    public goToMainMenu(): void {
        // Return back to the main menu scene
        cc.director.loadScene("mainMenu");
    }
}
