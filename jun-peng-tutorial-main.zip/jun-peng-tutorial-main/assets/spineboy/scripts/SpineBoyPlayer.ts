const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {
    @property(sp.Skeleton)
    private skeleton: sp.Skeleton = undefined!;

    @property(cc.Node)
    private star: cc.Node = undefined!;

    private hoverHeight: number = 20;

    private isRightDown: boolean = false;
    private isLeftDown: boolean = false;
    private isRunning: boolean = false;
    private isJumping: boolean = false;
    public isShooting: boolean = false;
    private isDead: boolean = false;

    private velocityX: number = 0;
    private velocityY: number = 0;
    private jumpSpeed: number = 360;

    private groundY: number = undefined!;
    private minX: number = undefined!;
    private maxX: number = undefined!;
    private gravity: number = undefined!;
    public initBoundaries(groundY: number, minX: number, maxX: number, gravity: number) {
        this.groundY = groundY;
        this.minX = minX;
        this.maxX = maxX;
        this.gravity = gravity;
    }

    private triggerGameOver!: () => void;
    private togglePause!: () => void;
    public initGameFunctions(triggerGameOver: () => void, togglePause: () => void) {
        this.triggerGameOver = triggerGameOver;
        this.togglePause = togglePause;
    }

    @property(cc.Integer)
    walkSpeed: number = 200;

    @property(cc.Integer)
    runSpeed: number = 400;

    protected lateUpdate(dt: number): void {
        if (!this.star || !cc.isValid(this.star)) {
            this.isDead = true;

            // Play death animation
            let currentTrack = this.skeleton.getCurrent(0);
            if (!currentTrack || currentTrack.animation.name !== "death") {
                this.skeleton.clearTracks();
                let deathTrack = this.skeleton.setAnimation(0, "death", false);

                this.skeleton.setTrackCompleteListener(deathTrack, () => {
                    this.triggerGameOver();
                });
            }
            return;
        }

        // Update star position on top of player
        this.star.x = this.node.x;
        this.star.y = this.node.y + 140 + this.hoverHeight;
    }

    protected onLoad(): void {
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
    }

    protected onDestroy(): void {
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
    }

    private onKeyDown(event: cc.Event.EventKeyboard): void {
        if (this.isDead) return;

        switch (event.keyCode) {
            case cc.macro.KEY.d:
                this.isRightDown = true;
                this.updateAnimation();
                break;

            case cc.macro.KEY.a:
                this.isLeftDown = true;
                this.updateAnimation();
                break;

            case cc.macro.KEY.shift:
                this.isRunning = true;
                this.updateAnimation();
                break;

            case cc.macro.KEY.w:
                this.jump();
                break;

            case cc.macro.KEY.space:
                let shootingScript = this.node.getComponent("PlayerShooter");
                shootingScript.shoot();
                break;

            case cc.macro.KEY.p:
                this.togglePause();
                break;
        }
    }

    private onKeyUp(event: cc.Event.EventKeyboard): void {
        if (this.isDead) return;

        switch (event.keyCode) {
            case cc.macro.KEY.d:
                this.isRightDown = false;
                this.updateAnimation();
                break;

            case cc.macro.KEY.a:
                this.isLeftDown = false;
                this.updateAnimation();
                break;

            case cc.macro.KEY.shift:
                this.isRunning = false;
                this.updateAnimation();
                break;
        }
    }

    private jump() {
        if (this.isJumping) return;

        if (this.node.y >= this.groundY) {
            this.isJumping = true;
            this.skeleton.setAnimation(0, "jump", false);
            this.velocityY = this.jumpSpeed;
        }

        // Manually change according to spine animation !!!
        let totalJump = 100;
        cc.Tween.stopAllByTarget(this.skeleton.node);
        cc.tween(this.skeleton.node)
            .sequence(
                cc.tween().by(0.7, { y: -totalJump }, { easing: "quadOut" }),
                cc.tween().by(0.6, { y: totalJump }, { easing: "quadIn" })
            )
            .start();
    }

    private updateAnimation() {
        if (this.isJumping) return;

        if (this.isRightDown) this.node.scaleX = 1;
        if (this.isLeftDown) this.node.scaleX = -1;

        let targetAnimation = "idle";
        if (this.isRightDown || this.isLeftDown) {
            targetAnimation = this.isRunning ? "run" : "walk";
        }

        let currentEntry = this.skeleton.getCurrent(0);
        if (!currentEntry || currentEntry.animation.name !== targetAnimation) {
            this.skeleton.setAnimation(0, targetAnimation, true);
        }
    }

    protected update(dt: number): void {
        if (this.isDead) return;
        this.calculateXMovement();
        this.calculateYMovement(dt);
        this.setMovementAndBoundary(dt);
    }

    private calculateXMovement() {
        let currSpeed = this.isRunning ? this.runSpeed : this.walkSpeed;
        if (this.isRightDown) {
            this.velocityX = currSpeed;
        } else if (this.isLeftDown) {
            this.velocityX = -currSpeed;
        } else {
            this.velocityX = 0;
        }
    }

    private calculateYMovement(dt: number) {
        if (this.node.y > this.groundY || this.velocityY > 0) {
            this.velocityY -= this.gravity * dt;
        } else {
            this.velocityY = 0;
            this.node.y = this.groundY;
            if (this.isJumping) {
                this.isJumping = false;
                this.updateAnimation(); // Revert to walk/run/idle upon landing
            }
        }
    }

    private setMovementAndBoundary(dt: number) {
        // Apply final position updates manually
        let pos = this.node.position;
        pos.x += this.velocityX * dt;
        pos.y += this.velocityY * dt;

        // Wall Boundary
        if (pos.x < this.minX) {
            pos.x = this.minX;
        } else if (pos.x > this.maxX) {
            pos.x = this.maxX;
        }

        // Prevent falling through the floor line
        if (pos.y < this.groundY) {
            pos.y = this.groundY;
        }

        this.node.position = pos;
    }

    public playShootAnimation(): void {
        if (this.isShooting) return;

        this.isShooting = true;
        let shootEntry = this.skeleton.setAnimation(1, "shoot", false);
        this.skeleton.addAnimation(0, "idle", true, 0);

        this.skeleton.setTrackCompleteListener(shootEntry, () => {
            // Check if the animation that just finished was the "shoot" animation
            let animName = shootEntry.animation ? shootEntry.animation.name : "";
            if (animName === "shoot") {
                this.isShooting = false;
            }
        });
    }
}
