const { ccclass, property } = cc._decorator;

@ccclass
export default class SpinePoolManager extends cc.Component {
    @property(cc.Prefab)
    private blobPrefab: cc.Prefab = undefined!;

    @property(cc.Prefab)
    private ammoPrefab: cc.Prefab = undefined!;

    @property(cc.Prefab)
    private bulletPrefab: cc.Prefab = undefined!;

    // Node Pools
    private blobPool: cc.NodePool = undefined!;
    private ammoPool: cc.NodePool = undefined!;
    private bulletPool: cc.NodePool = undefined!;

    public initializeNodePools() {
        this.blobPool = new cc.NodePool();
        this.ammoPool = new cc.NodePool();
        this.bulletPool = new cc.NodePool();

        // Preloading Pools
        this.preloadPools();
    }

    private preloadPool(prefab: cc.Prefab, pool: cc.NodePool, count: number): void {
        if (!prefab) return;
        for (let i = 0; i < count; i++) {
            let node = cc.instantiate(prefab);
            pool.put(node);
        }
    }

    private preloadPools() {
        this.preloadPool(this.blobPrefab, this.blobPool, 10);
        this.preloadPool(this.ammoPrefab, this.ammoPool, 5);
        this.preloadPool(this.bulletPrefab, this.bulletPool, 2);
    }

    // Getter and Setter Function
    private getObjectFromPool(pool: cc.NodePool, prefab: cc.Prefab): cc.Node {
        let node = pool.size() > 0 ? pool.get()! : cc.instantiate(prefab);
        return node;
    }
    private setObjectFromPool(node: cc.Node, spawnPos: cc.Vec2, parentNode: cc.Node): cc.Node {
        node.active = true;
        node.parent = parentNode;
        node.setPosition(spawnPos);

        return node;
    }

    // Functions to spawn each Node
    public getAndSetBlob(spawnPos: cc.Vec2, parentNode: cc.Node) {
        let node = this.getObjectFromPool(this.blobPool, this.blobPrefab);
        node = this.setObjectFromPool(node, spawnPos, parentNode);
        return node;
    }
    public getAndSetAmmo(spawnPos: cc.Vec2, parentNode: cc.Node) {
        let node = this.getObjectFromPool(this.ammoPool, this.ammoPrefab);
        node = this.setObjectFromPool(node, spawnPos, parentNode);
        return node;
    }
    public getAndSetBullet(spawnPos: cc.Vec2, parentNode: cc.Node) {
        let node = this.getObjectFromPool(this.bulletPool, this.bulletPrefab);
        node = this.setObjectFromPool(node, spawnPos, parentNode);
        return node;
    }

    // Recycle Function
    private recycleNode(node: cc.Node, nodePool: cc.NodePool): void {
        if (!node || !cc.isValid(node)) return;
        node.active = false;
        node.removeFromParent();
        nodePool.put(node);
    }

    // Functions to recycle nodes
    public recycleBlob(node: cc.Node): void {
        this.recycleNode(node, this.blobPool);
    }
    public recycleAmmo(node: cc.Node): void {
        this.recycleNode(node, this.ammoPool);
    }
    public recycleBullet(node: cc.Node): void {
        this.recycleNode(node, this.bulletPool);
    }
}
