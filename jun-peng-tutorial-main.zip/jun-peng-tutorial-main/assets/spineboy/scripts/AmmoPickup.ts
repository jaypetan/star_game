const { ccclass, property } = cc._decorator;

@ccclass
export default class AmmoPickup extends cc.Component {
    @property(cc.Integer)
    public ammoReload: number = 3;

    @property
    private fallSpeed: number = 500;

    @property(cc.AudioClip)
    public pickupSound: cc.AudioClip = undefined!;

    @property
    private floatHeight: number = 30;
    private floatDuration: number = 1;

    private isGrounded: boolean = false;
    private groundY: number = undefined!;
    public setGroundY(groundY: number) {
        this.groundY = groundY;
    }

    public initAmmo() {
        cc.Tween.stopAllByTarget(this.node);
        this.isGrounded = false;
    }

    protected update(dt: number): void {
        let currentPos = this.node.position;

        if (!this.isGrounded) {
            // if it isn't grounded, it will fall until it hits the ground, then hop
            currentPos.y -= this.fallSpeed * dt;

            if (currentPos.y <= this.groundY) {
                currentPos.y = this.groundY;
                this.isGrounded = true;
                this.playContinuousHop();
            }

            this.node.position = currentPos;
        }
    }

    private playContinuousHop(): void {
        cc.tween(this.node)
            .repeatForever(
                cc
                    .tween()
                    .to(
                        this.floatDuration,
                        {
                            position: new cc.Vec2(
                                this.node.position.x,
                                this.node.position.y + this.floatHeight
                            ),
                        },
                        { easing: "smooth" }
                    )
                    .to(
                        this.floatDuration,
                        { position: new cc.Vec2(this.node.position.x, this.node.position.y) },
                        { easing: "smooth" }
                    )
            )
            .start();
    }
}
